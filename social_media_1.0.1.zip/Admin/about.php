<br>
<!--- ABOUT SECTION --->
<div class="abt">
  <h2 class="abt_header">Web Developer</h2>
  <center>
    <img class="logo" src="images/ghs3.png" />
</center>
<div class="content_area">
  <span class="big">Hi</span>, I'm <a href="#">Juliee</a> . I'm A Web
  Developer And Web Designer . I'm A
  <font style="color: #cd6000">Student Of University</font> . I'm Doing A
  Graduation Name Honours Department Of English . I'm From
  <font style="color: #9200de">Washington DC</font> , I Currently Live In
  <font style="color: #007707">USA (Techoma City)</font>
  . Programming And Cooding Is My Favourite Things . I Love Codding So Much
  , I'v been <font style="color: #0b39d5">Codding Since 2019</font> . My
  Repositories And Projects Has Given Bellow ,
  <font style="color: #ff003c">Please Check</font> . And Also Follow Me On
  My Sociall Medias And Marketplaces .
  <font style="color: #ff00ec">Thank You !</font>
  <br />
<h1 class="about">Education Info</h1>

<li>
  School :
  <strong style="color: #ce6600">Govt Heigh School</strong>
</li>
<li>
  College :
  <strong style="color: #ce6600">Govt College</strong>
</li>
<li>
  University :
  <strong style="color: #ce6600">
    National University Of Bangladesh
  </strong>
</li>
<li>
  Profession :
  <strong style="color: #ce6600"> Web Developer & Designer </strong>
</li>
<li>
  Email :
  <strong style="color: #0000ff"> ghsjulian@gmail.com </strong>
</li>
<li>
  Phone :
  <strong style="color: #ce6600"> +880XXXXXXXX70 </strong>
</li>
<div class="social-links mt-3 text-center">
  <center>
    <a style="background-color: #0073ea" href="#" class="twitter"
      ><i class="bx bxl-twitter">t</i></a
    >
    <a style="background-color: #239bff" href="#" class="facebook"
      ><i class="bx bxl-facebook">f</i></a
    >
    <a style="background-color: #ff2b00" href="#" class="instagram"
      ><i class="bx bxl-instagram">i</i></a
    >
    <a style="background-color: #0e00ff" href="#" class="google-plus"
      ><i class="bx bxl-skype">s</i></a
    >
    <a style="background-color: #00aa35" href="#" class="linkedin"
      ><i class="bx bxl-linkedin">l</i></a
    >
  </center>
</div>
</div>
<br />
</div>

<!----FINISHED ABOUT SECTION----->
