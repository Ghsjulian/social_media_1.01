 <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="utf-8" />
  <meta
  name="viewport"
  content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
<meta
name="description"
content="G H S J U L I A  N | Ghs Julian | Web Developer And Designer | Ghs Julian Programmer | PHP Developer & Programmer | Programmer Ghs Julian"/>
<meta
name="author"
content="G H S J U L I A  N | Ghs Julian | Web Developer And Designer | Ghs Julian Programmer | PHP Developer & Programmer | Programmer Ghs Julian"/>
<title>
G H S J U L I A N | Ghs Julian | Web Developer And Designer | Ghs Julian
Programmer | PHP Developer & Programmer | Programmer Ghs Julian
</title>
<link rel="stylesheet" type="text/css" href="css/w3.css" />
<link rel="stylesheet" type="text/css" href="css/i4ndex.css" />
<link rel="stylesheet" type="text/css" href="css/home.css" />
<link rel="stylesheet" type="text/css" href="css/update_info.css" />
<link rel="stylesheet" type="text/css" href="css/popup.css" />
<link rel="stylesheet" type="text/css" href="css/login.css" />
<link rel="stylesheet" href="css/nav.css" />
<link rel="stylesheet" href="css/bts.min.css" />
<script src="js/jquery.min.js"></script>
</head>
<body>
<div class="abt">
  <h2 class="abt_header">Web Developer</h2>
  <center>
    <img class="logo" src="images/ghs.png" />
</center>
<div class="content_area">
  <span class="big">Hi</span>, I'm <a href="#">Juliee</a> . I'm A Web
  Developer And Web Designer . I'm A
  <font style="color: #cd6000">Student Of University</font> . I'm Doing A
  Graduation Name Honours Department Of English . I'm From
  <font style="color: #9200de">Washington DC</font> , I Currently Live In
  <font style="color: #007707">USA (Techoma City)</font>
  . Programming And Cooding Is My Favourite Things . I Love Codding So Much
  , I'v been <font style="color: #0b39d5">Codding Since 2019</font> . My
  Repositories And Projects Has Given Bellow ,
  <font style="color: #ff003c">Please Check</font> . And Also Follow Me On
  My Sociall Medias And Marketplaces .
  <font style="color: #ff00ec">Thank You !</font>
  <br/><br/>
  <h1 style="color:#00ccff">How Create An Account ?</h1>
  <br/>
  
  ( 1 ) First Open The Website On Your Favourite Browser , I'll Suggest Chrome Browser .
  
( 2 ) Now You Can See A Login Interface Infront You . If You've Already An Account then You Can Login . Or If You've Not
Any Account Then At First You've To Create An Account . So Now Click The Link Don't Have An Account ?

( 3 ) Now You Can See A Registration Page On Your Browser . Please Fill Out The Registration Form And Click The
Registration Button . 

( 4 ) If Your Information Is Valid , Then You Can See The Another Form . Now Please Complete This Sction , Select An
Image For Your Profile . Add Your Addresses And Click On The "Let's Go Button" .

( 5 ) After Completing This Section ! You'll Be Redirect To The Home Page . Wow Congratulation You've Successfully
Created Your Account , And From Now You Can Use The Website !

 <br />
  <h1 style="color:#00ccff">What User Can Do ?</h1>
  <strong style="color : #046a0a">
  (1) One User Can Follow To Another User Like Instagram !


  (2) Once An User Followed An User Then They Will Be Connected And They Can Send Messages To Each Other !


  (3) Registred User Can Like Comments And Write Post Also !
  
  (4) It's Amazing , I Love This Project !
  </strong>
 <br/><br/>
  <h1 style="color:#00ccff">How To Install ?</h1>
  <br/><br/>
  <strong style="color : #505050">
  (1) Download The ZIP File Or Clone This Repository .
  
  (2) Now Extract The ZIP 
  
  (3) You Can See A Folder Name "Database/"
  
  (4) Inside The Database Folder You'll See A .sql File Name "my_data" .
  
  (5) Now Go To Your Apachee Server And Run Your Server And Go To Your Chrome Browser And Type
  "http://localhost:8080/phpmyaddmin".
  
  (6) Go To Your Phpmyaddmin And Create A Database Name "my_data" . 
  
  (7) After Creating The Database , Click On Import Button .
  
  (8) Now Upload The "my_data.sql" According To Your Project Folder Which You've Downloded .
  
  (9) After Uploading The SQl File Close The Browser Back To The Project Folder And Again Go To The Database Folder And
  You Can See The "Database.php" File . Now Let's Open This File On Our Favourite Editor And Press (CTRL + F) On Your
  Keyboard And Search Connection Section .
  
  (10) Now Edit The Constractor Method !
  ```
  $host = "localhost" //live server addresses
  $user_name  = "root" // Live Server Database User Name
  $password = "" //Live Server Database Password 
  $db_name = "my_data" //Live Server Database Name
  ```
  Now Save The File And Close It !
  
  (11) Now Open The "conn.php" Which Is In The Same Folder , Let's Edit This File Like Before  And Save It .
  
  (12) Open The File And Edit Connection Settings And Save It !
  
  (13) Congratulation !!!
  
  (14) Let's Open The Chrome Browser And Type "http://localhost:8080/social_media/" And Press Enter !
  
  (15) Let's Create An Account And Use It ?
  
  </strong>
  
  <br/><br/><br/>
    <h1 style="color:#ff00ce">Thank You !!!</h1>
  <br/><br/>
  
</div>
<!----FINISHED ABOUT SECTION----->
</body></html>