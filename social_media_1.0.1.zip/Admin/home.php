<?php 
include('header.php');
?>


<!--- Nav Bar Ended --->
    
    
    
    <div class="news-feed">
      <div class="poster">
        <img src="images/user2.png" /><strong
          ><a href="#">Ghs Julian</a></strong
        >
      </div>
      <div align="left" class="post_area">
        <content>
          Hello , User I'm Julian . I Am A Web Developer And Designer . Welcome
          To My Site . This Is My Social Media Web Site...
        </content>
      </div>
      <div align="center" class="actions">
        <button name="request_btn" type="button" class="action_btn" id="like">
          <img class="like_btn" src="images/like.svg" />
        </button>
        <button name="request_btn" type="button" class="action_btn" id="love">
          <img src="images/love.svg" />
        </button>
        <button
          name="request_btn"
          type="button"
          class="action_btn"
          id="comment"
        >
          <img src="images/comment.svg" />
        </button>
      </div>

      <div class="comment_area">
        <div class="commenter">
          <img src="images/user2.png" />
          <input
            class="comment_btn value"
            type="text"
            name="comment"
            placeholder="Write A Comment..."
          />
          <button type="submit" class="comment_btn" name="comment_btn">
            <img src="images/send.svg" />
          </button>
        </div>
      </div>
    </div>

    <div class="news-feed">
      <div class="poster">
        <img src="images/user2.png" /><strong
          ><a href="#">Ghs Julian</a></strong
        >
      </div>
      <div align="left" class="post_area">
        <content>
          Hello , User I'm Julian . I Am A Web Developer And Designer . Welcome
          To My Site . This Is My Social Media Web Site...
        </content>
      </div>
      <div align="center" class="actions">
        <button name="request_btn" type="button" class="action_btn" id="like">
          <img class="like_btn" src="images/like.svg" />
        </button>
        <button name="request_btn" type="button" class="action_btn" id="love">
          <img src="images/love.svg" />
        </button>
        <button
          name="request_btn"
          type="button"
          class="action_btn"
          id="comment"
        >
          <img src="images/comment.svg" />
        </button>
      </div>

      <div class="comment_area">
        <div class="commenter">
          <img src="images/user2.png" />
          <input
            class="comment_btn value"
            type="text"
            name="comment"
            placeholder="Write A Comment..."
          />
          <button type="submit" class="comment_btn" name="comment_btn">
            <img src="images/send.svg" />
          </button>
        </div>
      </div>
    </div>

<?php 
include('footer.php');
?>