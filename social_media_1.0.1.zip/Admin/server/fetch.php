<?php
session_start();
$info = $_SESSION['user_info'];
$user_id = $info['user_id'];
$message = array();
include('../database/conn.php');




$all_user = "SELECT * FROM users WHERE user_id != '$user_id'";

$query2 = mysqli_query($conn, $all_user);

while ($data = mysqli_fetch_array($query2)) {

  $user_id = $data['user_id'];
  $user_name = $data['user_name'];
  $avtar = $data['user_image'];


  $message[] = array(
    "user_id" => $user_id,
    "user_name" => $user_name,
    "avtar" => $avtar,
  );
  echo json_encode($message);
}
?>