<?php
session_start();
include('../database/database.php');
include('../database/conn.php');
$db = new Database();
$message = array();



function loginInfo($name, $conn) {
  $sql = "SELECT * FROM users WHERE user_name = '$name'";
  $query = mysqli_query($conn, $sql);
  $result = mysqli_fetch_array($query);
  return $result;
}



if ($_POST['action'] == 'Registration') {

  $name = $_POST['user_name'];
  $email = $_POST['user_email'];
  $password = $_POST['user_password'];
  $has_password = sha1($password);

  if ($name && $email && $password) {
    $sql = "SELECT * FROM users WHERE user_name = '$name' AND user_email = '$email'";
    if ($db->selectData($sql)) {
      $message = array(
        "stattus" => false,
        "message" => "User Already Registered !"
      );
    } else {
      $sql_insert = "INSERT INTO
      users(user_id,user_name,user_email,user_password)VALUES('','$name','$email','$has_password')";
      if ($db->insertData($sql_insert)) {
        $_SESSION['user_info'] = loginInfo($name, $conn);
        $message = array(
          "stattus" => "Registration",
          "message" => "Registration Successfully !",
        );
      } else {
        $message = array(
          "stattus" => false,
          "message" => "Registration Failed!"
        );
      }
    }
  } else {
    $message = array(
      "stattus" => false,
      "message" => "Please Fill Out the Form !"
    );
  }
  echo json_encode($message);
}


if ($_POST['action'] == 'Login') {

  $name = $_POST['user_name'];
  $password = $_POST['user_password'];
  $has_password = sha1($password);

  if ($name && $has_password) {
    $sql = "SELECT * FROM users WHERE user_name = '$name' AND user_password =
  '$has_password' ";
    $sql5 = "UPDATE users SET user_status = 'Online' WHERE user_name = '$name'";
    mysqli_query($conn, $sql5);
    $fire = $db->selectData($sql);
    $db_name = $fire['user_name'];
    $db_password = $fire['user_password'];
    $user_role = $fire['user_status'];
    if ($has_password == $db_password) {
      if ($user_role == 'admin') {
        $message = array(
          "stattus" => "Login",
          "url" => "admin/index.php",
          "message" => "Login Successfully !",
        );
        $_SESSION['user_info'] = $fire;
      } else {
        $message = array(
          "stattus" => "Login",
          "url" => "index.php",
          "message" => "Login Successfully !",
        );
        $_SESSION['user_info'] = $fire;
      }
    }
  } else {
    $message = array(
      "stattus" => false,
      "message" => "Invalid Password !",
    );
  }
  echo json_encode($message);
}
?>