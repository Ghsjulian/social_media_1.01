<?php
session_start();
$info = $_SESSION['user_info'];
$user_id = $info['user_id'];
$message = array();
include('../database/conn.php');


if (isset($_POST['post_id'])) {
  $post_id = $_POST['post_id'];

  $sql = "SELECT post_id,liker FROM reaction WHERE liker = '$user_id' AND post_id = '$post_id'";
  $query = mysqli_query($conn, $sql);
  if (mysqli_num_rows($query) == 0) {
    $insert = "UPDATE posts SET count = count +1 WHERE post_id = '$post_id'";
    $query_insert = mysqli_query($conn, $insert);
    if ($query_insert) {
      $isert_id = "INSERT INTO reaction(post_id,liker) VALUES('$post_id','$user_id')";
      $insert_query = mysqli_query($conn, $isert_id);
      if ($insert_query) {
        $get_count = "SELECT count FROM posts WHERE post_id = '$post_id'";
        $get_query = mysqli_query($conn, $get_count);
        $data = mysqli_fetch_array($get_query);
        $count = $data['count'];
        echo json_encode(array(
          "count" => $count,
          "Liked" => true
        ));
      }
    }
  } elseif (mysqli_num_rows($query) == 1) {
    $del = "UPDATE `posts` SET `count` = count -1 WHERE post_id = '$post_id'";
    $query_del = mysqli_query($conn, $del);
    if ($query_del) {
      $delete = "DELETE FROM reaction WHERE liker = '$user_id'";
      $del_all = mysqli_query($conn, $delete);
      if ($del_all) {
        $get_count = "SELECT count FROM posts WHERE post_id = '$post_id'";
        $get_query = mysqli_query($conn, $get_count);
        $data = mysqli_fetch_array($get_query);
        $count = $data['count'];
        echo json_encode(array(
          "count" => $count,
          "Unliked" => false
        ));
      }
    }
  }
}


/*________________________________
      LOVE REACTION ❣️
_______________________________*/


if (isset($_POST['love'])) {
  $post_id = $_POST['post_id'];

  $sql = "SELECT post_id,lover FROM reaction WHERE lover = '$user_id' AND post_id = '$post_id'";
  $query = mysqli_query($conn, $sql);
  if (mysqli_num_rows($query) == 0) {
    $insert = "UPDATE posts SET love = love +1 WHERE post_id = '$post_id'";
    $query_insert = mysqli_query($conn, $insert);
    if ($query_insert) {
      $isert_id = "INSERT INTO reaction(post_id,lover) VALUES('$post_id','$user_id')";
      $insert_query = mysqli_query($conn, $isert_id);
      if ($insert_query) {
        $get_count = "SELECT love FROM posts WHERE post_id = '$post_id'";
        $get_query = mysqli_query($conn, $get_count);
        $data = mysqli_fetch_array($get_query);
        $count = $data['love'];
        echo json_encode(array(
          "count" => $count,
          "Loved" => true
        ));
      }
    }
  } else {
    $del = "UPDATE `posts` SET `love` = love -1 WHERE post_id = '$post_id'";
    $query_del = mysqli_query($conn, $del);
    if ($query_del) {
      $delete = "DELETE FROM reaction WHERE lover = '$user_id'";
      $del_all = mysqli_query($conn, $delete);
      if ($del_all) {
        $get_count = "SELECT love FROM posts WHERE post_id = '$post_id'";
        $get_query = mysqli_query($conn, $get_count);
        $data = mysqli_fetch_array($get_query);
        $count = $data['love'];
        echo json_encode(array(
          "count" => $count,
          "Unloved" => false
        ));
      }
    }
  }
}


if (isset($_POST['comment'])) {
  $comment = $_POST['comment'];
  $post_id = $_POST['post-id'];
  if (!empty($comment)) {
    $sql = "INSERT INTO reaction (post_id,commenter,comment) VALUES ('$post_id','$user_id','$comment')";
    $query = mysqli_query($conn, $sql);

    $insert = "UPDATE posts SET comment = comment+1 WHERE post_id = '$post_id'";
    $query_insert = mysqli_query($conn, $insert);

    $fetch = "SELECT comment FROM posts WHERE post_id = '$post_id'";
    $fetch_query = mysqli_query($conn, $fetch);
    $data = mysqli_fetch_array($fetch_query);

    Allcomments($post_id);

    /*  echo json_encode(array(
      "comment" => true,
      "count" => $data[0],
      "get_comment" => $comment
    ));
*/
  }
}

function fetch_comments($post_id) {
  include('../database/conn.php');
  $comments = array();
  $fetch = "SELECT post_id,commenter,comment FROM reaction WHERE post_id = '$post_id'";
  $fetch_query = mysqli_query($conn, $fetch);
  while ($data = mysqli_fetch_all($fetch_query)) {

    $text = $data['comment'];
    $commenter = $data['commenter'];
    $comments[] = array(
      "text" => $text,
      "commenter_name" => getUser($commenter)['user_name'],
      "commenter_img" => getUser($commenter)['user_image'],
    );
    echo json_encode($comments);
  }
}

function getUser($id) {
  include('../database/conn.php');
  $sql = "SELECT * FROM users WHERE user_id = '$id'";
  $query = mysqli_query($conn, $sql);
  if ($query) {
    $result = mysqli_fetch_array($query);
    return $result;
  }
}



if (isset($_POST['fetch_comment'])) {
  $post_id = $_POST['post-id'];
  if (countComment($post_id)) {
    $fetch = "SELECT post_id,commenter,comment FROM reaction WHERE post_id = '$post_id'";

    $fetch_query = mysqli_query($conn, $fetch);
    while ($dat = mysqli_fetch_array($fetch_query)) {
      ?>
      <div class="user">
        <img id="u_avtar" src="upload/<?php echo getUser($dat['commenter'])['user_image']; ?>" />
      <strong><?php echo getUser($dat['commenter'])['user_name']; ?></strong>
    </div>
    <p id="text">
      <?php echo $dat['comment']; ?>
    </p>
    <hr />
  <?php
}
} else {
echo "<br><strong>No Comment Yet !</strong><br>";
}
}




function Allcomments($id) {
include('../database/conn.php');
$post_id = $_POST['post-id'];
$fetch = "SELECT post_id,commenter,comment FROM reaction WHERE post_id = '$post_id'";

$fetch_query = mysqli_query($conn, $fetch);
while ($dat = mysqli_fetch_array($fetch_query)) {
?>
<div class="user">
<img id="u_avtar" src="upload/<?php echo getUser($dat['commenter'])['user_image']; ?>" />
<strong><?php echo getUser($dat['commenter'])['user_name']; ?></strong>
</div>
<p id="text">
<?php echo $dat['comment']; ?>
</p>
<hr />
<?php
}
}


function countComment($id) {
include('../database/conn.php');
$sql = "SELECT comment FROM posts WHERE post_id = '$id'";
$query2 = mysqli_query($conn, $sql);
$data = mysqli_fetch_array($query2);
return $data['comment'];
}

if (isset($_POST['count_comment'])) {
echo countComment($_POST['postid']);
}

?>