<?php
session_start();
$info = $_SESSION['user_info'];
$user_id = $info['user_id'];
$user_name = $info['user_name'];
include('../database/database.php');
include('../database/conn.php');
$db = new Database();
$message = array();
if ($_FILES['photo']['name'] || $_POST['country'] || $_POST['city'] || $_POST['profession'] || $_POST['school']) {

  $user_avtar = $_FILES['photo']['name'];

  $country = trim($_POST['country']);

  $city = trim($_POST['city']);

  $profession = trim($_POST['profession']);

  $school = trim($_POST['school']);

  $extension = pathinfo ($user_avtar, PATHINFO_EXTENSION);
  $valid_extension = array("jpg", "png", "jpeg");
  if (in_array($extension, $valid_extension)) {
    $new_name = trim($user_name).rand().".".$extension;
    $path = "../upload/".$new_name;
    if (move_uploaded_file($_FILES['photo']['tmp_name'], $path)) {

      $insert_info = "UPDATE `users` SET
      `user_image`='$new_name',`user_country`='$country',`user_profession`='$profession',`user_school`='$school',`user_city`='$city'
      WHERE user_id = '$user_id'";
      if ($db->insertData($insert_info)) {
        $sql = "SELECT * FROM users WHERE user_id = '$user_id'";
        $_SESSION['user_info'] = $db->selectData($sql);
        echo "1";

      } else {
        echo "An Error Has Occurred!";
      }
    }
  } else {
    echo 'Please Select An Image Which Format Is (jpg,jpeg,png)';
  }
}


if (isset($_POST['write_post'])) {
  include('../database/conn.php');
  $post = $_POST['write_post'];
  $sql = "INSERT INTO `posts`(`poster_id`,`post_content`)VALUES('$user_id','$post')";

  if (mysqli_query($conn, $sql)) {
    echo 'Posted';
  }
}



if (isset($_POST['noti'])) {
  $send = array();
  $sql = "SELECT reciver_id FROM request WHERE reciver_id = '$user_id'";
  $query = mysqli_query($conn, $sql);
  //$data = mysqli_fetch_array($query);

  echo mysqli_num_rows($query);

}


function getInfo($id, $conn) {
  $sql = "SELECT * FROM users WHERE user_id = '$id'";
  $query = mysqli_query($conn, $sql);
  if ($query) {
    $result = mysqli_fetch_array($query);
    return $result;
  }
}



if (isset($_POST['connected_people'])) {
  $arr = array ();
  $sql = "SELECT requester, accepter FROM connected WHERE (requester = '$user_id' OR accepter = '$user_id')";
  $query = mysqli_query($conn, $sql);
  if ($query) {
    while ($result = mysqli_fetch_array($query)) {
      $friend_id = "";
      if ($result['accepter'] !== $user_id || $result['accepter'] !== $user_id) {
        $friend_id = $result['accepter'];
      } else {
        $friend_id = $result['requester'];
      }

      if (getInfo($friend_id, $conn)['user_status'] == "Online") {
        echo " <li class='w3-list' id='".getInfo($friend_id, $conn)['user_id']."' onclick='Chatbox(".getInfo($friend_id,
          $conn)['user_id'].")'>
          <div id='online'>
          <img align='left' src='upload/".getInfo($friend_id,
          $conn)['user_image']."'/>
          <span style='background-color: #25d50c' class='w3-badge'></span>
          </div>
          <strong>".getInfo($friend_id, $conn)['user_name']."</strong></li> <div style='display:none' hidden='true' u_id='".getInfo($friend_id,
          $conn)['user_id']." id='connect'></div>";
      } else {
        echo " <li class = 'w3-list' id='".getInfo($friend_id, $conn)['user_id']."' onclick = 'Chatbox(".getInfo($friend_id,
          $conn)['user_id'].")'> <div id='offline'> <img align='left' src='upload/".getInfo($friend_id,
          $conn)['user_image']."'/> <span style= 'background-color: #636363' class='w3-badge'></span> </div > <strong> ".getInfo($friend_id, $conn)['user_name']." </strong></li> <div style='display:none' hidden='true' u_id='".getInfo($friend_id,
          $conn)['user_id']." id='connect'></div>";
      }
    }
  }
}

if (isset($_POST['_people'])) {
  $chat_id = $_POST['chat_id'];
  $chat_info = getInfo($chat_id, $conn);

  $fixed .= "<div id='__header' class='fixed-top msg_header'>
        <img id='msg_user' src='upload/".$chat_info['user_image']."'><strong
    id='chat_user_name' onclick='userProfile(".$chat_id.")'>".$chat_info['user_name']."</strong>
<img onclick='closeChat()' id='cancle' src='images/cross.png'>
</div><div class='chat_page'>
<div class='msg-inbox'>
<div class='chats'>
<div id='msg-page' class='msg-page'>";

  $fixed .= "</div></div>
</div>
</div>
</div><div id='__header' class='fixed-bottom msg_footer'>
<img style='display: block' id='msg_user' src='images/cmr3.png'>
<textarea id='text_message' placeholder='Write A Message...'></textarea>
<button onclick='SendMessage()' id='send_btn'><img id='cancle' src='images/send.svg'></button>
</div>
<input style='display:none' id='hidden_chat_id' value='".$chat_id."' hidden='true'>
  ";
 $fixed .= "<div style='display:none' id='pop_page' class='w3-modal'>
  </div>";
  echo $fixed;
  //Allmessage($chat_id, $conn, $user_id);
}





if (isset($_POST['send_message'])) {
  $reciver = $_POST['Toid'];
  $message = $_POST['sendText'];
  $sql = "INSERT INTO `messages`(`msg_sender`, `msg_reciver`, `text_message`) VALUES
  ('$user_id','$reciver','$message')";
  $query = mysqli_query($conn, $sql);
  if ($query) {
    echo "Sent";
  }
}

function Allmessage($toid, $conn, $user_id, $info) {
  $sql2 = "SELECT * FROM messages WHERE (msg_sender = '$user_id' AND msg_reciver = '$toid') OR (msg_reciver =
    '$user_id' AND msg_sender = '$toid')";
  $query2 = mysqli_query($conn, $sql2);
  if (mysqli_num_rows($query2) > 0) {
    while ($result = mysqli_fetch_array($query2)) {
      if ($result['msg_sender'] === $user_id) {
        echo "       <!--- RIGHT SIDE---->
        <div class='sender-chats'>
          <div class='sender-chats-images'>
            <img id='left_user' src='upload/".$info['user_image']."' />
        </div>
        <div class='sender-msg'>
          <p>
      ".$result['text_message']."
          </p>
        </div>
      </div>
      <!---RIGHT SIDE ---->";
        // echo $result['text_message'];
      } else {
        $chat_info = getInfo($result['msg_sender'], $conn);
        echo "<!---- LEFT SIDE ----><div class='received-chats'><div class='received-chats-images'><img id='left_user'
      src='upload/".$chat_info['user_image']."'/></div><div
      class='received-msg'><p>".$result['text_message']."</p></div></div><!---- LEFT SIDE ---->";
        //  $result['text_message'];
      }
    }
  } else {
    echo "No Message Found ";
  }
}

if (isset($_POST['fetchMessage'])) {
  Allmessage($_POST['toid'], $conn, $user_id, $info);
}


if (isset($_POST['Message_Count'])) {
  $arr = array ();
  $sql = "SELECT requester, accepter FROM connected WHERE (requester = '$user_id' OR accepter = '$user_id')";
  $query = mysqli_query($conn, $sql);
  if ($query) {
    while ($result = mysqli_fetch_array($query)) {
      $friend_id = "";
      if ($result['accepter'] !== $user_id || $result['accepter'] !== $user_id) {
        $friend_id = $result['accepter'];
      } else {
        $friend_id = $result['requester'];
        Allmessage($friend_id, $conn, $user_id, $info);
      }
    }
  }
}

?>