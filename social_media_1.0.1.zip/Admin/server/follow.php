<?php
session_start();
$info = $_SESSION['user_info'];
$user_id = $info['user_id'];
$user_name = $info['user_name'];
$user_image = $info['user_image'];
include('../database/database.php');
include('../database/conn.php');
$db = new Database();
$message = array();


if (isset($_POST['data'])) {

  $query = trim($_POST['data']);

  $sql = "SELECT * FROM users WHERE user_id = '$query'";

  $fire = $db->selectData($sql);
  $reciver_name = $fire['user_name'];
  $reciver_image = $fire['user_image'];
  $insert = "INSERT INTO request (sender_id,sender_name,sender_image,reciver_id)VALUES('$user_id','$user_name','$user_image','$query')";

  if ($db->insertData($insert)) {
    $message = array(
      "message" => true,
    );
  }
  echo json_encode($message);
}






if (isset($_POST['accept'])) {

  $query = trim($_POST['accept']);
  $insert = "INSERT INTO connected (requester, accepter) VALUES ('$query','$user_id')";
  if (mysqli_query($conn, $insert)) {
    $sql = "DELETE FROM request WHERE sender_id = '$query' AND reciver_id = '$user_id'";
    mysqli_query($conn, $sql);
    echo true;
  }
}

?>