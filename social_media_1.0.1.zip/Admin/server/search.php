<?php
session_start();
$info = $_SESSION['user_info'];
$user_id = $info['user_id'];
$user_name = $info['user_name'];
include('../database/database.php');
include('../database/conn.php');
$db = new Database();
$res = array();



if (isset($_POST['data'])) {

  $search = trim($_POST['data']);

  $sql = "SELECT * FROM users WHERE NOT user_id = '$user_id' AND (user_name LIKE '%$search%') ";

  $query = mysqli_query($conn, $sql);

  if (mysqli_num_rows($query) > 0) {
    while ($user = mysqli_fetch_assoc($query)) {
      ?>

      <!---------------->
      <div id="<?php echo $user['user_id']; ?>" class="area">
        <div class="find_friend">
          <img src="upload/<?php echo $user['user_image']; ?>" />
        <strong><a onclick="userProfile('<?php echo $user['user_id']; ?>')" href="#"><?php echo $user['user_name']; ?></a></strong>
        <button data="<?php echo $user['user_id']; ?>" id="follow_btn" class="flw_btn">Follow</button>
      </div>
    </div>
    <!---------------->

    <?php
  }
} else {
  ?>
  <div id="<?php echo $user['user_id']; ?>" class="area">
    <div class="find_friend">
      <strong>No User Found !</strong>
    </div>
  </div>
  <?php
}
}
?>