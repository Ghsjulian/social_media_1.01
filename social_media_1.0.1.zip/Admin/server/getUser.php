<?php
session_start();
$info = $_SESSION['user_info'];
$sission_id = $info['user_id'];
$message = array();
include('../database/conn.php');


$id = $_POST['data'];

$all_user = "SELECT * FROM users WHERE user_id = '$id'";

$query2 = mysqli_query($conn, $all_user);

$data = mysqli_fetch_array($query2);

$user_id = $data['user_id'];
$user_name = $data['user_name'];
$avtar = $data['user_image'];
$sql7 = "SELECT requester, accepter FROM connected WHERE (requester = '$sission_id' AND accepter = '$user_id') OR
(requester = '$user_id' AND accepter = '$sission_id')";
$query7 = mysqli_query($conn, $sql7);
$user_status = "";
$user_s = "";
if (mysqli_num_rows($query7)) {
  $user_status = "followed";
  $user_s = "Following";
} else {
  $user_status = "not_following";
  $user_s = "Follow";
}
$message[] = array(
  "user_id" => $user_id,
  "user_name" => $user_name,
  "avtar" => $avtar,
  "school" => $data['user_school'],
  "city" => $data['user_city'],
  "country" => $data['user_country'],
  "profession" => $data['user_profession'],
  "user_status" => $user_status,
  "user_s" => $user_s,
);
echo json_encode($message);

?>