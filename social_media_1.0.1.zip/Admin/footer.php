<!---------------->
<script src="js/router.js"></script>
<script type="module" src="./js/nav.js"></script>
<script type="module" src="./js/search.js"></script>
<script src="js/follow.js"></script>
<script src="js/reload.js"></script>
<script src="js/index.js"></script>

</body>
</html>