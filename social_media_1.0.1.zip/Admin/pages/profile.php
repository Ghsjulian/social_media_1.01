<!--
<div class="w3-row">
  <div class="w3-col">
    <div class="w3-round w3-white">
      <div class="w3-container">-->
<center>
  <div class="ghs_profile">
    <img src="upload/<?php echo $info['user_image']; ?>" /><br />
<strong><?php echo $info['user_name']; ?></strong>
<h3><?php echo $info['user_profession']; ?></h3>

<div class="social-links mt-3 text-center">
  <center>
    <a href="#" class="twitter"
      ><i class="bx bxl-twitter">t</i></a
    >
    <a href="#" class="facebook"
      ><i class="bx bxl-facebook">f</i></a
    >
    <a href="#" class="instagram"
      ><i class="bx bxl-instagram">i</i></a
    >
    <a href="#" class="google-plus"
      ><i class="bx bxl-skype">s</i></a
    >
    <a href="#" class="linkedin"
      ><i class="bx bxl-linkedin">l</i></a
    >
  </center>
</div>
<hr />
<button onclick="fetch_user()" id="action_btn" to="/profile" data="<?php echo $info['user_id']; ?>">Follow</button>
<button id="action_btn" data="<?php echo $info['user_id']; ?>">Message</button>
<button onclick="openNav('Edit')" id="action_btn">Edit</button>

<h5>About Info :</h5>

<ul>
<li>Profession : <?php echo $info['user_profession']; ?></li>
<li>School/College : <?php echo $info['user_school']; ?></li>
<li>City : <?php echo $info['user_city']; ?></li>
<li>Country : <?php echo $info['user_country']; ?></li>
<!---<li>Birthday : 04 January 2003</li>--->
</ul>
</div>
</center><!---
</div>
</div>
</div>
</div>--->
<br />
<!---------------->