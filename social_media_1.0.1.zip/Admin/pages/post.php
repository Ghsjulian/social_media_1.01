<?php
session_start();
$info = $_SESSION['user_info'];
$user_id = $info['user_id'];
include('database/conn.php');

$sql = "SELECT * FROM posts";

$query2 = mysqli_query($conn, $sql);

while ($data = mysqli_fetch_array($query2)) {

  $user_id = $data['user_id'];
  $user_name = $data['user_name'];
  $avtar = $data['user_image'];
}
?>