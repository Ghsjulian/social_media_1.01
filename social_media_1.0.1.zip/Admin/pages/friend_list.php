<?php
include('database/conn.php');
function getInfo($id, $conn) {
  $sql = "SELECT * FROM users WHERE user_id = '$id'";
  $query = mysqli_query($conn, $sql);
  if ($query) {
    $result = mysqli_fetch_array($query);
    return $result;
  }
}

$sql = "SELECT requester, accepter FROM connected WHERE accepter = '$user_id' OR requester = '$user_id'";
$query = mysqli_query($conn, $sql);
if ($query) {
  while ($result = mysqli_fetch_array($query)) {
    $friend_id = "";
    if ($result['accepter'] !== $user_id) {
      $friend_id = $result['accepter'];
    } elseif ($result['requester'] !== $user_id) {
      $friend_id = $result['requester'];
    }
    ?>
    <ul id="connected_people" class="w3-ul chatlist">
    </ul>
    <?php
  }
}
?>
