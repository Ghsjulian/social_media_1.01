<center>
  <div class="search">
    <input id="search" type="text" placeholder="Search...">
    <button type="search">🔎</button>
  </div>
  <div id="search_area"></div>
</center>
<div id="list"></div>

















<?php
/*________________________________
    SELECT FROM REQUEST TABLE
________________________________*/


/*
$sql = "SELECT sender_id FROM request";

$query = mysqli_query($conn, $sql);
while ($req = mysqli_fetch_array($query)) {
$all_user = "SELECT * FROM users WHERE user_id != '$req_id'";

$query_all = mysqli_query($conn, $all_user);
while ($data = mysqli_fetch_array($query_all)) {


  $sndr_id = $req['sender_id'];
  $rcv_id = $req['reciver_id'];
*/
// echo $rcv_id."<br>";
/*_______________________________
     SELECT FROM USERS TABLE
________________________________*/
/*
function getUser($id) {
  include('../database/conn.php');
  $sql = "SELECT * FROM users WHERE user_id = '$id'";
  $query = mysqli_query($conn, $sql);
  if ($query) {
    $result = mysqli_fetch_array($query);
    return $result;
  }
}*/
function request($u_id, $session_id, $conn) {
  $sql = "SELECT sender_id,reciver_id FROM request WHERE sender_id = '$u_id' AND reciver_id = '$session_id' OR sender_id = '$session_id' AND reciver_id = '$u_id'";
  $query = mysqli_query($conn, $sql);
  if ($query) {
    $result = mysqli_fetch_array($query);
    return $result;
  }
}
function connected($u_id, $session_id, $conn) {
  $sql = "SELECT requester, accepter FROM connected WHERE requester = '$u_id' AND accepter = '$session_id' OR requester = '$session_id' AND accepter = '$u_id'";
  $query = mysqli_query($conn, $sql);
  if ($query) {
    $result = mysqli_fetch_array($query);
    return $result;
  }
}





$all_user = "SELECT * FROM users WHERE user_id != '$user_id'";

$query2 = mysqli_query($conn, $all_user);

while ($data = mysqli_fetch_array($query2)) {
  $u_id = $data['user_id'];
  $user_name = $data['user_name'];
  $avtar = $data['user_image'];

  if (!connected($u_id, $user_id, $conn) && !request($u_id, $user_id, $conn)) {

    ?>

    <!---------------->
    <div id="<?php echo $u_id; ?>" class="area">
      <div class="find_friend">
        <img src="upload/<?php echo $avtar; ?>" />
      <strong><a id="f_link" href="#php?id=27" onclick="userProfile('<?php echo $u_id; ?>')"><?php echo $user_name; ?></a></strong>
      <button data="<?php echo $u_id; ?>" id="follow_btn" class="flw_btn">Follow</button>
    </div>
  </div>
  <!---------------->
  <?php
}
}
?>