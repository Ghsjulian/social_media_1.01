<?php
session_start();
$info = $_SESSION['user_info'];
$user_id = $info['user_id'];
$message = array();
//include('header.php');
$sql = "SELECT * FROM request WHERE reciver_id = '$user_id'";

$query = mysqli_query($conn, $sql);
if (mysqli_num_rows($query) > 0) {
  while ($data = mysqli_fetch_array($query)) {
    $sender_id = $data['sender_id'];
    $sender_name = $data['sender_name'];
    $sender_avtar = $data['sender_image'];

    ?>


    <ul id="noti_btn" class="w3-ul noti" img="<?php echo $sender_avtar; ?>"name="<?php echo $sender_name; ?>"
      uid="<?php echo $sender_id; ?>">
      <li class="w3-list">
        <img align="left" src="upload/<?php echo $sender_avtar; ?>" /><strong
        ><?php echo $friends_name; ?></strong
      >
      <p>
        <?php echo $sender_name; ?></b> Followed You !
    </p>
  </li>
</ul>

<!--
  <div id="noti_btn" class="area notification" img="<?php echo $sender_avtar; ?>" name="<?php echo $sender_name; ?>"
    uid="<?php echo $sender_id; ?>">
    <div>
      <img src="upload/<?php echo $sender_avtar; ?>" />
    <strong
      ><b style="color: #00abd5"><?php echo $sender_name; ?></b> followed you ! Will you
      accept it ?</strong
    >
  </div>
</div>--->

<?php
}
} else {
?>
<br><br>
<h3>No Notification </h3>

<?php
}
?>


<div id="pop_page" class="w3-modal">
<div id="modal_page" class="w3-container">

</div>
</div>

<?php

//include('footer.php');
?>