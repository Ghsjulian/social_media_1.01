<br><br>

<!---------------->

<center>
  <form name="myfrm" id="myfrm">
    <strong align="center" class="up_profile"> Write A Post </strong>

    <div align="center" class="info_area">
     <!--- <div class="post_avtar">
        <label for="photo">
          <img align="center" id="view" src="images/cmr4.png" />
      </label>
      <input
      id="photo"
      type="file"
      name="photo"
      onchange="previewFile(this);"
      accept="image/*"
      />
  </div>--->

  <div class="post">
    <span id="Err"></span><br>
    <textarea id="post" name="post" placeholder="Write Something..."></textarea>
  </div>
  <button id="post_btn" class="post_btn">Publish Now</button>
</div>
</form>
<br />
</center>
<script>


//  IMAGE VIEWS FOR PROFILE PICTURE

function previewFile(input) {
var file = $("input[type=file]").get(0).files[0];
console.log(file);
if (file) {
var reader = new FileReader();
reader.onload = function () {
$("#view").attr("src", reader.result);
};
reader.readAsDataURL(file);
}
}




var post_btn = document.getElementById("post_btn");
var err = document.getElementById("Err");
post_btn.addEventListener("click", function (e) {
e.preventDefault();
form = document.getElementById("myfrm");

var form_data = new FormData();
var post = document.getElementById("post").value.trim().toLowerCase();
if (
post.includes("</>") ||
post.includes("<") ||
post.includes(">") ||
post.includes("/") ||
post.includes("alert") ||
post.includes("=") ||
post.includes("|") ||
post.includes("&") ||
post.includes("?") ||
post.includes(";") ||
post.includes("*") ||
post.includes("@") ||
post.includes("(") ||
post.includes(")") ||
post.includes("[") ||
post.includes("]") ||
post.includes("{") ||
post.includes("}") ||
post.includes("_") ||
post.includes("hot") ||
post.includes("sex") ||
post.includes("sexy") ||
post.includes("fucking") ||
post.includes("fuck") ||
post.includes("pussy") ||
post.includes("bobs") ||
post.includes("sucking") ||
post.includes("hot girl") ||
post.includes("nonsense") ||
post.includes("what")) {
err.classList.remove("error");
err.classList.add("error");
err.textContent = "You Can't Post It !";
} else if (post.trim() == "") {

err.classList.remove("error");
err.classList.add("error");
err.textContent = "Please Write Something !";
} else {

form_data.append("write_post", post);
fetch("server/function.php", {
method: "POST",
body: form_data
})
.then((res) => {
return res.text();
})
.then((data) => {
openNav('Home');
document.getElementById("post").value = "";

});
}
});
</script>
<!---------------->