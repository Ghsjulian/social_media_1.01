<div style="display:block" id="log_pop" class="w3-modal">
  <div id="modal_page" class="w3-container">
    <div id="" class="log_pop w3-animate-top" align="center">
      <img src="images/warning.png" />
    <br />
  <strong> Are You Sure ? </strong>
  <br><button onclick="logout()" type="submit" id="__submit_btn" sender_id="${uid}">Logout</button>
  <button onclick="openNav('Home')" id="__cancle_btn">Cancel</button>
</div>
</div>
</div>