<?php
session_start();
include('database.php');
include('conn.php');
$mydata = new Database ();



print_r($_SESSION['user_info']);


$ghs = array(
  "name" => "Ghs Julian",
  "city" => "New Yourk"
);

$gbs = array(
  "name" => "Maria Smith",
  "city" => "Washington"
);
$new = array(
  $ghs, $gbs
);


/*
foreach ($new as $a) {
  echo $a['name']." <br>";
}
*/
//print_r($new[1]['name']);












/*___________________________________
    MAKE OBJECT LIKE ABOVE AND USE IT ANY WHERE . IT'S AN AWESOME CODING , OOP I
    LOVE THIS METHODS. HOPE MY CODE IS USEFUL . IF YOU HAVE EDITED THE CONFIG
    JSON FILE . SO YOU DON'T NEED TO EDIT THIS FILE JUST GO TO YOUR BROWSER AND
    TYPE " http://localhost:8080/your_project/database/check.php"
____________________________________*/
?>