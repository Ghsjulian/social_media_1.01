<?php
session_start();
$info = $_SESSION['user_info'];
$user_id = $info['user_id'];
include('conn.php');
$sql5 = "UPDATE users SET user_status = 'Offline' WHERE user_id = '$user_id'";
if (mysqli_query($conn, $sql5)) {
  session_destroy();
//session_unset();
echo 'Logout';
}
?>