<?php
class Database {
  public $conn;
  public $connection;
  public $msg;

  public function __construct() {
    $host = 'localhost';
    $user_name = 'root';
    $password = '';
    $database = 'my_data';
    $db_name = 'my_data';

    $this->conn = new mysqli($host, $user_name, $password, $db_name);
    if ($this->conn) {
      $this->connection = true;
      return true;
    } else {
      echo "Database Connected Failed!";
      $this->connection = false;
      return false;
    }
  }


  public function selectData($sql = null) {
    $result = $this->conn->query($sql);
    if ($result->num_rows > 0) {
      $data = $result->fetch_assoc();
      return $data;
      return true;
    } else {
      return false;
    }
  }



  public function Delete($sql = null) {
    $result = $this->conn->query($sql);
    if ($result) {
      echo 'deleted';
    } else {
      return false;
    }
  }










  public function selectAll($sql = null) {
    $result = $this->conn->query($sql);
    if ($result->num_rows > 0) {
      $data = $result->fetch_all();
      return $data;
      return true;
    } else {
      return false;
    }
  }





  public function fetchAll($sql = null) {
    $query = mysqli_query($this->conn, $sql);
    return mysqli_fetch_array($query);
  }




  public function insertData($sql) {
    if ($sql) {
      $query = $this->conn->query($sql);
      if ($query) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

}
?>